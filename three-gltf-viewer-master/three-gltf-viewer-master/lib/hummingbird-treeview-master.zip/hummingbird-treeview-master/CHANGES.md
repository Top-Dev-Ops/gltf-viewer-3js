# CHANGES

## 2020/01/30

- New option: Customizable hover effect.

## 2019/12/22

- Add on functions: *select-single-node* and *select-single-group*.

## 2019/12/22

- New section "Add on options and functionality".

## 2019/12/04

- New option *singleGroupOpen* to allow only one group to be open and collapse all others.

## 2019/08/31

- Implementation of case-insensitive filter search as default with ability to override. Thanks to Mrkbingham.

## 2019/04/30

- Now Font-Awesome 5 is supported, see documentation how to use it.














